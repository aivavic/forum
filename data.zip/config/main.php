<?php

return [
    'SiteName' => 'Forum',
    'baseUrl' => 'http://' . $_SERVER['SERVER_NAME'],
    'db' => require (__DIR__) . '/db.php',
];