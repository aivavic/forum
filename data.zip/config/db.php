<?php

return [
    'host'      => 'localhost',
    'database'  => 'forum1.3',
    'user'      => 'root',
    'password'  => '',
];
