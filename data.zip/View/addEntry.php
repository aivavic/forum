<?php

$obj = new AddEntryClass();
$obj->addMessage();
$obj->addMessageFileToBd();