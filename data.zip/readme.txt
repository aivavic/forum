/config/main.php - Общие настройки сайта
/congig/db.php   - Настройки для БД

/data/forum1_3.php - дамп базы

/db_content/messages.txt - временный файл для отправки в базу большого количества записей за раз
(используется в /core/AddEntryClass.php)